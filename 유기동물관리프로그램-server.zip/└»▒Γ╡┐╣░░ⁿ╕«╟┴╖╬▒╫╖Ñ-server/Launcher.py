from InternetAnimal import*
from xml.dom.minidom import parse, parseString
from xml.etree import ElementTree

loopFlag = 1
AnimalsDoc = None

def printMenu():
    print('\nWelcome! Animal Manager Program')
    print('========== Menu ==========')
    print('Load xml: l')
    print('print Animal list: p')
    print('==========================')

def launcherFunction(menu):
    if menu == 'l':
        LoadXMLFromFile()
    elif menu == 'p':
        PrintAnimalList()
    else:
        print('ERROR: unknow menu key')

def LoadXMLFromFile():
    fileName = str(input('please input file name to load: '))
    global AnimalsDoc
    try:
        dom = parse(fileName)
    except Exception:
        print('ERROR: loading fail')
    else:
        print('XML Document loading complete')
        AnimalsDoc = dom
        return dom
    return None

def AnimalsFree():
    if checkDocument():
        AnimalsDoc.unlink()

def PrintAnimalList():
    global AnimalslDoc
    if not checkDocument():
        return None

    Animallist1 = AnimalsDoc.childNodes
    Animallist2 = Animallist1[0].childNodes
    Animallist3 = Animallist2[1].childNodes
    Animal = Animallist3[0].childNodes
    for item in Animal:
        if item.nodeName == 'item':
            subitems = item.childNodes
            for atom in subitems:
                if atom.nodeName in 'age':
                    print('나이: ', atom.firstChild.nodeValue)
                if atom.nodeName in 'careAddr':
                    print('보호 장소: ', atom.firstChild.nodeValue)
                if atom.nodeName in 'careNm':
                    print('보호소 이름: ', atom.firstChild.nodeValue)
                if atom.nodeName in 'careTel':
                    print('보호소 전화번호: ', atom.firstChild.nodeValue)
                if atom.nodeName in 'colorCd':
                    print('색: ', atom.firstChild.nodeValue)
                if atom.nodeName in 'happenPlace':
                    print('발견 장소: ', atom.firstChild.nodeValue)
                if atom.nodeName in 'kindCd':
                    print('축종: ', atom.firstChild.nodeValue)
                if atom.nodeName in 'sexCd':
                    print('성별: ', atom.firstChild.nodeValue)
                    print('\n')

def checkDocument():
    global AnimalsDoc
    if AnimalsDoc == None:
        print('ERROR: Document is empty')
        return False
    return True

def QuitAnimalMgr():
    global loopFlag
    loopFlag = 0
    AnimalsFree()

while (loopFlag > 0):
    printMenu()
    menukey = str(input('select menu: '))
    launcherFunction(menukey)
else:
    print('Thank you! Good Bye')
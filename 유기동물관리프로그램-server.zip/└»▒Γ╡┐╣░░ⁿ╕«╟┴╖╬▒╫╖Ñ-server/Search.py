import InternetAnimal

def SearchAnimalSex(keyword) :
    for item in InternetAnimal.animalList :
        if(item['성별']==keyword) :
            print(item)

def SearchAnimalArea(keyword) :
    for item in InternetAnimal.animalList :
        if(item['관할기관']==keyword) :
            print(item)

def SearchAnimalKind(keyword) :
    for item in InternetAnimal.animalList :
        if(item['축종']==keyword) :
            print(item)

import Search
import InternetAnimal

loopFlag = 1

def printMenu():
    print('================M E N U================')
    print('종료 : 0')
    print('전체 출력 : 1')
    print('성별로 검색 : 2')
    print('지역으로 검색 : 3')
    print('종류로 검색 : 4')
    print('=======================================')

def launcherFunction(menu):
    if menu == 0 :
        global loopFlag
        loopFlag = 0
    if menu == 1 :
        for item in InternetAnimal.animalList :
            print(item)
    if menu == 2 :
        keyword = str(input('성별 입력(M/F) : '))
        Search.SearchAnimalSex(keyword)
    if menu == 3 :
        keyword = str(input('지역 입력(시도 시군구) : '))
        Search.SearchAnimalArea(keyword)
    if menu == 4 :
        keyword = str(input('종류(축종) : '))
        keyword = '[' + keyword + ']'
        if(keyword == '[개]') :
            breads = str(input('품종 : '))
            keyword = keyword + ' ' + breads
        Search.SearchAnimalKind(keyword)

while(loopFlag > 0) :
    printMenu()
    menuKey = int(input ('메뉴를 선택하세요 : '))
    launcherFunction(menuKey)
else :
    print('종료합니다.')

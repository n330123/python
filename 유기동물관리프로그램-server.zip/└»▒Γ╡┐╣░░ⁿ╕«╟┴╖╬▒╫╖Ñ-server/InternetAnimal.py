# coding: utf-8

from http.client import HTTPConnection
from http.server import BaseHTTPRequestHandler, HTTPServer
from xml.etree import ElementTree

conn = None
server = 'openapi.animal.go.kr'
type = 'abandonmentPublic'
key = 'eVsoaZvhhkQhlgRn%2F%2BHKFZM7Pbob28TY%2BGFE9%2BMgq5qum5e22G0Y85%2F3V36c1EQEAgQr8zoeiyzQDEDazY394w%3D%3D'
num = '10'

def userURIBuilder(server, type, **user):
    str = 'http://' + server + '/openapi/service/rest/abandonmentPublicSrvc/' + type + '?'
    for key in user.keys():
        str += key + '=' + user[key] + '&'
    print(str)
    return str

def connectOpenAPIServer():
    global conn, server
    conn = HTTPConnection(server)

def getAnimalDataFromITEM(item):
    global conn, server, num, key
    if conn == None:
        connectOpenAPIServer()
    uri = userURIBuilder(server, type, numOfRows=num, ServiceKey=key)
    conn.request('GET', uri)

    req = conn.getresponse()
    if int(req.status) == 200:
        print('Animal data downloading complete')
        return req.read()
    else:
        print('OpenAPI requset has been failed! please retry')
        return None

def extractAnimalData(strXml):
    tree = ElementTree.fromstring(strXml)
    AnimalElements = tree.getiterator('item')
    AnimalList = []

    for Animal in AnimalElements:
        strAge = Animal.find('age')
        strCareAddr = Animal.find('careAddr')
        strCareNm = Animal.find('careNm')
        strCareTel = Animal.find('careTel')
        strHappenPlace = Animal.find('happenPlace')
        strColorCd = Animal.find('colorCd')
        strKindCd = Animal.find('kindCd')
        strSexCd = Animal.find('sexCd')
        if len(strAge.text) > 0:
            AnimalList.append({'발견 장소':strHappenPlace.text, '보호 장소':strCareAddr.text, '보호소 이름':strCareNm.text,
                               '보호소 전화번호':strCareTel.text, '나이':strAge.text, '색':strColorCd.text, '축종':strKindCd.text, '성별':strSexCd.text})
    return AnimalList

if __name__ == '__main__':
    animalXML = getAnimalDataFromITEM(None)
    animalList = extractAnimalData(animalXML)
    print(animalList)
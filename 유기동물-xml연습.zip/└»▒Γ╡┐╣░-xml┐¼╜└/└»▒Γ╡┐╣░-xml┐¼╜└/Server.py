from AnimalMgr import *
from http.client import HTTPConnection
from http.server import BaseHTTPRequestHandler, HTTPServer

conn = None

server =
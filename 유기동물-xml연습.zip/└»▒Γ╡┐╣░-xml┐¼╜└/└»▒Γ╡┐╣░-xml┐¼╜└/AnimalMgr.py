from xml.dom.minidom import parse, parseString
from xml.etree import ElementTree

loopFlag = 1
AnimalsDoc = None

def printMenu():
    print('\nWelcome! Animal Manager Program (xml version)')
    print('==========Menu==========')
    print('Load xml: l')
    print('Print dom to xml: all')
    print('Print Animal list: p')
    print('Quit program: q')
    print('====================')

def launcherFunction(menu):
    global AnimalsDoc
    if menu == 'l':
        AnimalsDoc = LoadXMLFromFile()
    elif menu == 'all':
        PrintDOMtoXML()
    elif menu == 'p':
        PrintAnimalsList()
    elif menu == 'q':
        QuitAnimalMgr()
    else:
        print('Error: unknow menu key')

def LoadXMLFromFile(): #파일 불러오기
    fileName = str(input('please input file name to load: '))
    try:
        dom = parse(fileName)
    except Exception:
        print('Error: loading fail')
    else:
        print('XML Document loading complete')
        return dom
    return None

def PrintDOMtoXML():
    if checkDocument():
        print(AnimalsDoc.toxml())

def checkDocument():
    global AnimalsDoc
    if AnimalsDoc == None:
        print('Error: Document is empty')
        return False
    return True

def PrintAnimalsList():
    global AnimalsDoc
    if not checkDocument():
        return None
    Animalslist1 = AnimalsDoc.childNodes
    Animalslist2 = Animalslist1[0].childNodes
    Animalslist3 = Animalslist2[1].childNodes
    Animals = Animalslist3[0].childNodes
    for item in Animals:
        if item.nodeName == 'item':
            subitems = item.childNodes
            for atom in subitems:
                if atom.nodeName in 'age':
                    print('나이: ', atom.firstChild.nodeValue)
                if atom.nodeName in 'careAddr':
                    print('보호 장소: ', atom.firstChild.nodeValue)
                if atom.nodeName in 'careNm':
                    print('보호소 이름: ', atom.firstChild.nodeValue)
                if atom.nodeName in 'careTel':
                    print('보호소 전화번호: ', atom.firstChild.nodeValue)
                if atom.nodeName in 'colorCd':
                    print('색: ', atom.firstChild.nodeValue)
                if atom.nodeName in 'happenPlace':
                    print('발견 장소: ', atom.firstChild.nodeValue)
                if atom.nodeName in 'kindCd':
                    print('축종: ', atom.firstChild.nodeValue)
                if atom.nodeName in 'sexCd':
                    print('성별: ', atom.firstChild.nodeValue)
                    print('\n')

def QuitAnimalMgr():
    global loopFlag
    loopFlag = 0
    AnimalsFree()

def AnimalsFree():
    if checkDocument():
        AnimalsDoc.unlink()

while (loopFlag > 0):
    printMenu()
    menuKey = str(input('Select Menu: '))
    launcherFunction(menuKey)
else:
    print('Thank you! Good Bye')

from xml.dom.minidom import parse, parseString
from xml.etree import ElementTree

loopFlag = 1
AnimalsDoc = None

def printMenu():
    print('\nWelcome! Animal Manager Program (xml version)')
    print('==========Menu==========')
    print('Load xml: load')
    print('Print dom to xml: print')
    print('Print careAddr list: careAddr :발견 장소')
    print('Print careNm list: careNm :보호소 이름')
    print('Quit program: quit')
    print('====================')

def launcherFunction(menu):
    global AnimalsDoc
    if menu == 'load':
        AnimalsDoc = LoadXMLFromFile()
    elif menu == 'print':
        PrintDOMtoXML()
    elif menu == 'careAddr':
        PrintCareAddrList(['careAddr', ])
    elif menu == 'careNm':
        PrintCareNmList(['careNm', ])
    elif menu == 'quit':
        QuitAnimalMgr()
    else:
        print('Error: unknow menu key')

def LoadXMLFromFile(): #파일 불러오기
    fileName = str(input('please input file name to load: '))
    try:
        dom = parse(fileName)
    except Exception:
        print('Error: loading fail')
    else:
        print('XML Document loading complete')
        return dom
    return None

def PrintDOMtoXML():
    if checkDocument():
        print(AnimalsDoc.toxml())

def checkDocument():
    global AnimalsDoc
    if AnimalsDoc == None:
        print('Error: Document is empty')
        return False
    return True

def PrintCareAddrList(tags):
    global AnimalsDoc
    if not checkDocument():
        return None
    careAddrlist1 = AnimalsDoc.childNodes
    careAddrlist2 = careAddrlist1[0].childNodes
    careAddrlist3 = careAddrlist2[1].childNodes
    careAddr = careAddrlist3[0].childNodes
    for item in careAddr:
        if item.nodeName == 'item':
            subitems = item.childNodes
            for atom in subitems:
                if atom.nodeName in tags:
                    print('careAddr=', atom.firstChild.nodeValue)

def PrintCareNmList(tags):
    global AnimalsDoc
    if not checkDocument():
        return None
    careNmlist1 = AnimalsDoc.childNodes
    careNmlist2 = careNmlist1[0].childNodes
    careNmlist3 = careNmlist2[1].childNodes
    careNm = careNmlist3[0].childNodes
    for item in careNm:
        if item.nodeName == 'item':
            subitems = item.childNodes
            for atom in subitems:
                if atom.nodeName in tags:
                    print('careNm=', atom.firstChild.nodeValue)

def QuitAnimalMgr():
    global loopFlag
    loopFlag = 0
    AnimalsFree()

def AnimalsFree():
    if checkDocument():
        AnimalsDoc.unlink()

while (loopFlag > 0):
    printMenu()
    menuKey = str(input('Select Menu: '))
    launcherFunction(menuKey)
else:
    print('Thank you! Good Bye')
